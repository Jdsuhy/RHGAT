"""
RHGAT: A Hybrid Dual-graph Transformer with Hypergraph Contrastive Learning
for circRNA-miRNA Interaction Prediction.

circRNA-miRNA 关联预测模型训练流程。

RNA 基础模型增强 + 自适应双图结构学习 + 双流图 Transformer。

完整 pipeline：
1. RNA-FM 提取序列语义表示（离线已缓存）
2. Reliability-aware Gated Fusion 融合 sequence/structure/expression/similarity
3. Adaptive Bipartite Graph + Adaptive Hypergraph 双图结构学习
4. 双流 Graph Transformer + 双向 Cross-Attention
5. 三种自监督任务（节点掩码重建/图-超图对比/边恢复预测）
6. 困难负样本课程学习
7. 关系解码器预测关联概率

沿用 datasplit 的 1:1 负采样与 5 折划分，指标口径为
AUC/AUPR/F1/ACC/Precision/Recall/Specificity/MCC。
"""

import os
import random

import numpy as np
import torch
import torch as t
import torch.nn as nn
import torch.nn.functional as F

from sklearn.metrics import (
    roc_auc_score,
    average_precision_score,
)

from dataload import _get_datapro
from plot_utils import ROCPRPlotter
from rnafm_model import (
    ReliabilityAwareFusion,
    AdaptiveBipartiteGraph,
    AdaptiveHypergraph,
    BipartiteGraphTransformer,
    HypergraphTransformer,
    CrossAttentionFusion,
)
from rnafm_ssl import (
    cross_view_contrastive_loss,
    masked_edge_prediction_loss,
    HardNegativeMining,
    RelationDecoder,
    ContrastProjectionHead,
    EdgePredictionHead,
)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EMB_DIR = os.path.join(ROOT, "pretrained", "emb_cache")


class RNAFMModel(nn.Module):
    """完整的 RNA 基础模型增强 + 双图 + 双流 Transformer 模型。"""

    def __init__(self, args, circ_seq_dim, mir_seq_dim,
                 circ_view_dims, mir_view_dims):
        super().__init__()

        hidden = args.rfm_hidden
        self.hidden = hidden

        # ---- 多模态门控融合（circRNA 侧与 miRNA 侧各自融合） ----
        # circRNA 视图：sequence(RNA-FM) + structure + expression + similarity
        # miRNA  视图：sequence(RNA-FM) + structure + expression + similarity
        self.circ_fusion = ReliabilityAwareFusion(
            circ_view_dims, hidden
        )
        self.mir_fusion = ReliabilityAwareFusion(
            mir_view_dims, hidden
        )

        # ---- 自适应双图结构学习 ----
        self.bipartite = AdaptiveBipartiteGraph(
            hidden, hidden, topk=None, temperature=args.rfm_temperature
        )
        self.hypergraph_circ = AdaptiveHypergraph(
            hidden, args.num_hyperedges,
            temperature=args.hyper_temperature, topk=args.hyper_topk
        )
        self.hypergraph_mir = AdaptiveHypergraph(
            hidden, args.num_hyperedges,
            temperature=args.hyper_temperature, topk=args.hyper_topk
        )

        # ---- 双流 Transformer ----
        self.local_transformer = BipartiteGraphTransformer(
            hidden, num_layers=args.rfm_tf_layers,
            num_heads=args.rfm_heads, dropout=args.rfm_dropout,
            topk=args.bip_topk, agg_weight=args.graph_agg_weight,
        )
        self.global_transformer_circ = HypergraphTransformer(
            hidden, num_layers=args.rfm_tf_layers,
            num_heads=args.rfm_heads, dropout=args.rfm_dropout,
            agg_weight=args.graph_agg_weight,
        )
        self.global_transformer_mir = HypergraphTransformer(
            hidden, num_layers=args.rfm_tf_layers,
            num_heads=args.rfm_heads, dropout=args.rfm_dropout,
            agg_weight=args.graph_agg_weight,
        )

        # ---- 双向 Cross-Attention 融合 ----
        self.cross_circ = CrossAttentionFusion(
            hidden, num_heads=args.rfm_heads, dropout=args.rfm_dropout
        )
        self.cross_mir = CrossAttentionFusion(
            hidden, num_heads=args.rfm_heads, dropout=args.rfm_dropout
        )

        # ---- 关系解码器 ----
        self.decoder = RelationDecoder(hidden, hidden // 2)

        # ---- 节点掩码重建的投影层（Z -> 原始 sequence embedding 维度） ----
        self.recon_proj_circ = nn.Linear(hidden, circ_seq_dim)
        self.recon_proj_mir = nn.Linear(hidden, mir_seq_dim)

        # ---- 自监督任务头（与下游解码器解耦） ----
        # 对比投影头（SimCLR 风格，解耦对比任务与下游任务）
        self.contrast_proj = ContrastProjectionHead(hidden, hidden)
        # 边恢复预测头
        self.edge_head = EdgePredictionHead(hidden)

        # 是否启用图传播流（二部图/超图 + Transformer + 跨注意力）。
        # 关闭时退化为「门控融合 + 关系解码器」，避免节点表示过平滑坍缩。
        self.use_graph_stream = bool(getattr(args, 'use_graph_stream', 1))

    def encode(self, circ_feats, mir_feats):
        """
        circ_feats : (N_c, d_c) 融合前 circ 特征
        mir_feats  : (N_m, d_m) 融合前 mir 特征
        返回统一表示 Z_circ, Z_mir（用于打分）
        """
        # 1. 门控融合得到初始节点表示
        z_circ, _ = self.circ_fusion(circ_feats)
        z_mir, _ = self.mir_fusion(mir_feats)

        if not self.use_graph_stream:
            # 轻量路径：直接用融合表示（保留节点自身区分度）
            return z_circ, z_mir, z_circ, z_mir, None

        # 2. 自适应二部图
        B = self.bipartite(z_circ, z_mir)                  # (N_c, N_m)

        # 3. 自适应超图
        H_circ = self.hypergraph_circ(z_circ)              # (N_c, K)
        H_mir = self.hypergraph_mir(z_mir)                 # (N_m, K)

        # 4. 双流编码
        # 局部流（二部图消息传递 + Transformer）
        z_local_circ, z_local_mir = self.local_transformer(
            z_circ, z_mir, B
        )
        # 全局流（超图卷积 + Transformer）
        z_global_circ = self.global_transformer_circ(z_circ, H_circ)
        z_global_mir = self.global_transformer_mir(z_mir, H_mir)

        # 5. 双向 Cross-Attention 融合局部与全局
        Z_circ = self.cross_circ(z_local_circ, z_global_circ)
        Z_mir = self.cross_mir(z_local_mir, z_global_mir)

        return Z_circ, Z_mir, z_local_circ, z_local_mir, B

    def decode(self, Z_circ, Z_mir, circ_idx, mir_idx):
        """关系解码：预测边分数。"""
        return self.decoder(Z_circ, Z_mir, circ_idx, mir_idx)


class RNAFMExperiment:
    """训练流程封装，复用现有 datapro 的数据划分与指标计算。"""

    def __init__(self, args):
        self.args = args
        self.setup_seed(args.seed)

    def setup_seed(self, seed):
        t.manual_seed(seed)
        t.cuda.manual_seed_all(seed)
        random.seed(seed)
        np.random.seed(seed)
        t.backends.cudnn.deterministic = False
        t.backends.cudnn.benchmark = True

    # ------------------------------------------------------------------
    # 数据准备：加载 RNA-FM embedding + 相似度视图，构造成节点特征
    # ------------------------------------------------------------------
    def load_data(self):
        args = self.args
        dp = _get_datapro()

        # 相似度矩阵（节点间关系 -> 每行作为节点特征向量）
        circ_views = []
        mir_views = []
        for path in args.circRNA:
            sim = np.asarray(dp.read_csv(os.path.join(args.datapath, path + '.csv')),
                             dtype=np.float32)
            circ_views.append(sim)
        for path in args.miRNA:
            sim = np.asarray(dp.read_csv(os.path.join(args.datapath, path + '.csv')),
                             dtype=np.float32)
            mir_views.append(sim)

        # RNA-FM embedding（序列语义特征）
        circ_emb = np.load(os.path.join(EMB_DIR, 'circ_emb.npy'))
        mir_emb = np.load(os.path.join(EMB_DIR, 'mir_emb.npy'))
        circ_emb = circ_emb[:args.d_num].astype(np.float32)
        mir_emb = mir_emb[:args.m_num].astype(np.float32)

        # 关联矩阵
        circRNA_miRNA_matrix = _get_datapro().read_csv(
            os.path.join(args.datapath, 'circRNA_miRNA_matrix.csv')
        )
        circRNA_miRNA_matrix = circRNA_miRNA_matrix.T  # -> miRNA x circRNA
        m, n = circRNA_miRNA_matrix.shape

        # 数据划分（沿用现有 1:1 负采样 + k-fold）
        index = dp.datasplit(args, circRNA_miRNA_matrix)

        return {
            'circ_views': circ_views,       # list of (N_c, N_c)
            'mir_views': mir_views,          # list of (N_m, N_m)
            'circ_emb': circ_emb,            # (N_c, 640)
            'mir_emb': mir_emb,              # (N_m, 640)
            'label_matrix': circRNA_miRNA_matrix.numpy(),  # (m, n) miRNA x circ
            'index': index,                  # 5-fold 划分
            'm_num': args.m_num,
            'd_num': args.d_num,
        }

    # ------------------------------------------------------------------
    # 把相似度视图 + RNA-FM embedding 构造成有区分度的节点特征
    #
    # 关键根因（诊断确认）：
    # 1. RNA-FM embedding 是各向异性的——所有向量共享一个主导方向，平均
    #    cos≈0.983，虽然幅度 std≈0.5 有区分，但方向高度一致，导致后续
    #    门控融合/二部图 cosine 打分全部坍缩。修复：减去全局均值（中心化），
    #    消除主导方向后平均 cos 降至 ≈0.003，std 提升到 ≈0.27。
    # 2. 相似度矩阵行内值集中在 0.6~1.0，直接取行无区分度。用 SVD 取前
    #    d_sim 个主成分（U*S）投影到低维谱空间，再做中心化。
    # ------------------------------------------------------------------
    def build_node_feats(self, data):
        args = self.args
        d_sim = getattr(args, 'rfm_sim_dim', 64)

        circ_feats = []
        circ_view_dims = []
        mir_feats = []
        mir_view_dims = []

        # 1. sequence 视图：RNA-FM embedding 中心化（消除各向异性主导方向）
        circ_seq = self._center(data['circ_emb'])
        mir_seq = self._center(data['mir_emb'])
        circ_feats.append(circ_seq)
        circ_view_dims.append(circ_seq.shape[1])
        mir_feats.append(mir_seq)
        mir_view_dims.append(mir_seq.shape[1])

        # 2. structure / expression / similarity 视图：相似度矩阵 SVD 降维 + 中心化
        for v in data['circ_views']:
            low = self._center(self._svd_feature(v, d_sim))
            circ_feats.append(low)
            circ_view_dims.append(low.shape[1])
        for v in data['mir_views']:
            low = self._center(self._svd_feature(v, d_sim))
            mir_feats.append(low)
            mir_view_dims.append(low.shape[1])

        return (circ_feats, mir_feats, circ_view_dims, mir_view_dims)

    @staticmethod
    def _center(feat):
        """中心化：减去每个维度的全局均值，消除各向异性的主导方向。

        RNA-FM 等预训练模型产出的 embedding 常有一个所有样本共享的公共
        方向（主导主成分），它淹没了样本间的真实语义差异。减去均值后，
        平均余弦相似度从 ~0.98 降到 ~0.003，释放真正的序列区分度。
        """
        feat = np.asarray(feat, dtype=np.float32)
        return (feat - feat.mean(axis=0, keepdims=True)).astype(np.float32)

    @staticmethod
    def _svd_feature(sim_mat, d):
        """把 N×N 相似度矩阵降维为 N×d 的有区分度节点特征。

        用 SVD 取前 d 个主成分（U * S），得到每个节点的低维谱坐标。
        不做行归一化——范数本身携带节点在谱空间的尺度信息。
        """
        n = sim_mat.shape[0]
        k = min(d, n)
        u, s, _ = np.linalg.svd(sim_mat, full_matrices=False)
        feat = u[:, :k] * s[:k]                     # (N, k) 谱坐标
        return feat.astype(np.float32)

    # ------------------------------------------------------------------
    # 指标计算（AUC/AUPR/F1/ACC/Precision/Recall/Specificity/MCC）
    # ------------------------------------------------------------------
    def get_metrics(self, real_score, predict_score):
        real_score = np.asarray(real_score).flatten().astype(int)
        predict_score = np.asarray(predict_score).flatten()

        auc = roc_auc_score(real_score, predict_score)
        aupr = average_precision_score(real_score, predict_score)

        thresholds = np.linspace(predict_score.min(), predict_score.max(), 1000)
        sorted_score = np.sort(predict_score)
        n_pred_pos = len(sorted_score) - np.searchsorted(sorted_score, thresholds, side='left')
        pos_score = np.sort(predict_score[real_score == 1])
        tp = len(pos_score) - np.searchsorted(pos_score, thresholds, side='left')
        n_pos = int((real_score == 1).sum())
        n_neg = int((real_score == 0).sum())
        total = n_pos + n_neg

        tp = tp.astype(np.float64)
        fp = (n_pred_pos - tp).astype(np.float64)
        fn = (n_pos - tp).astype(np.float64)
        tn = (n_neg - fp).astype(np.float64)

        eps = 1e-10
        precision = tp / (tp + fp + eps)
        recall = tp / (tp + fn + eps)
        f1 = 2.0 * precision * recall / (precision + recall + eps)
        accuracy = (tp + tn) / (total + eps)
        specificity = tn / (tn + fp + eps)
        mcc_denom = np.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
        mcc = np.where(mcc_denom > 0, (tp * tn - fp * fn) / np.maximum(mcc_denom, eps), 0.0)

        max_index = int(np.argmax(f1))
        return [
            float(auc), float(aupr), float(f1[max_index]),
            float(accuracy[max_index]), float(precision[max_index]),
            float(recall[max_index]), float(specificity[max_index]),
            float(mcc[max_index]),
        ]

    # ------------------------------------------------------------------
    # 主训练
    # ------------------------------------------------------------------
    def train(self):
        args = self.args
        data = self.load_data()

        circ_feats, mir_feats, circ_view_dims, mir_view_dims = \
            self.build_node_feats(data)

        label = data['label_matrix']            # (m_num, d_num) miRNA x circ
        m_num = data['m_num']
        d_num = data['d_num']

        # 设备
        device = 'cuda' if torch.cuda.is_available() else 'cpu'

        # 困难负样本课程学习器
        hard_miner = HardNegativeMining(
            start_epoch=args.hard_start_epoch,
            curriculum_step=args.hard_step,
            hard_ratio_start=args.hard_ratio_start,
            hard_ratio_end=args.hard_ratio_end,
        )

        evaluation_results = {}
        per_fold_metrics = []
        metric = np.zeros((1, 8))

        # 收集每折最佳检查点的验证标签与预测分数，供 5 折 ROC/PR 绘图
        fold_plot_results = []

        for fold in range(args.k_fold):
            print("------ this is {}/{} cross validation ------".format(fold + 1, args.k_fold))

            # ---- 构建本折训练/验证矩阵 ----
            train_label = label.copy()
            val_pairs = np.array(data['index'][fold])   # (N_val, 2) 行=mRNA, 列=circ
            # 验证对从训练标签中抹除
            train_label[tuple(val_pairs.T)] = 0

            # ---- 构建模型 ----
            circ_seq_dim = data['circ_emb'].shape[1]
            mir_seq_dim = data['mir_emb'].shape[1]
            model = RNAFMModel(
                args, circ_seq_dim, mir_seq_dim,
                circ_view_dims, mir_view_dims,
            )
            model = model.to(device)

            optimizer = torch.optim.Adam(
                model.parameters(), lr=args.rfm_lr, weight_decay=args.rfm_wdecay
            )

            # 转换特征为 tensor
            circ_feats_t = [torch.from_numpy(f).float().to(device) for f in circ_feats]
            mir_feats_t = [torch.from_numpy(f).float().to(device) for f in mir_feats]

            train_label_t = torch.from_numpy(train_label).float().to(device)  # (m, d)

            # 正边（训练集）与负边候选池
            pos_idx = np.argwhere(train_label == 1)      # (E_pos, 2) (mir, circ)
            neg_idx = np.argwhere(train_label == 0)      # (E_neg, 2)

            # 正负样本（1:1 训练采样，沿用现有策略）
            n_pos = len(pos_idx)
            n_neg_sample = min(len(neg_idx), n_pos)
            rng = np.random.RandomState(args.seed + fold)

            # 困难负样本挖掘的候选池倍数：先随机采样 pool_ratio 倍的负边，
            # 再在其中按当前分数选困难负例，避免对全部数百万负边打分。
            pool_ratio = 5
            pool_size = min(len(neg_idx), n_neg_sample * pool_ratio)

            best_auc = 0
            best_aupr = 0
            best_result = None
            # 最佳检查点的验证标签与预测概率（sigmoid 后），供绘图
            best_val_labels = None
            best_val_probs = None

            for epoch in range(1, args.rfm_epochs + 1):
                model.train()

                # ---- 前向：得到统一表示 ----
                Z_circ, Z_mir, z_local_circ, z_local_mir, B = model.encode(
                    circ_feats_t, mir_feats_t
                )

                # ---- 负采样（困难负样本课程学习） ----
                # 先随机采样一个候选池（pool_size 条负边），再在池内按
                # 当前分数选困难负例，避免对全部负边打分。
                pool_sel = rng.choice(len(neg_idx), size=pool_size, replace=False)
                neg_pool = neg_idx[pool_sel]              # (pool_size, 2)

                neg_scores = self._score_edges(
                    model, Z_circ, Z_mir, neg_pool
                ).cpu().numpy()

                # 采样负边
                sel_neg = self._sample_negatives(
                    neg_pool, neg_scores, epoch, n_neg_sample, hard_miner, rng
                )

                # 训练边（正 + 采样负）
                pos_edges_t = torch.from_numpy(pos_idx).long().to(device)
                neg_edges_t = torch.from_numpy(sel_neg).long().to(device)

                # ---- 监督损失（关系解码） ----
                pos_score = model.decode(Z_circ, Z_mir, pos_edges_t[:, 1], pos_edges_t[:, 0])
                neg_score = model.decode(Z_circ, Z_mir, neg_edges_t[:, 1], neg_edges_t[:, 0])

                pos_loss = F.binary_cross_entropy_with_logits(
                    pos_score, torch.ones_like(pos_score)
                )
                neg_loss = F.binary_cross_entropy_with_logits(
                    neg_score, torch.zeros_like(neg_score)
                )
                sup_loss = pos_loss + neg_loss

                # ---- 自监督损失 ----
                # 1. 图-超图跨视图对比（仅在启用图传播流时有效，因为需要
                #    局部流/全局流两个视图；关闭时跳过）
                if model.use_graph_stream:
                    # 用投影头映射到对比空间（解耦对比与下游任务）
                    z_local_all = torch.cat([z_local_circ, z_local_mir], dim=0)
                    z_global_all = torch.cat([
                        model.global_transformer_circ(
                            Z_circ, model.hypergraph_circ(Z_circ)
                        ),
                        model.global_transformer_mir(
                            Z_mir, model.hypergraph_mir(Z_mir)
                        ),
                    ], dim=0)
                    z_local_proj = model.contrast_proj(z_local_all)
                    z_global_proj = model.contrast_proj(z_global_all)
                    contrast_loss = cross_view_contrastive_loss(
                        z_local_proj, z_global_proj,
                        temperature=args.rfm_cl_temp
                    )
                else:
                    contrast_loss = torch.tensor(0.0, device=device)

                # 2. 边恢复预测（掩码部分正边，用独立边打分头）
                edge_pred_loss = masked_edge_prediction_loss(
                    model.edge_head, Z_circ, Z_mir,
                    pos_edges_t, neg_edges_t,
                    mask_rate=args.rfm_edge_mask_rate,
                )

                # 3. 节点掩码重建（用原始特征作为目标）
                # 简化：用 circ/mir 的门控融合前特征做重建目标
                node_mask_loss = self._masked_node_loss(
                    model, Z_circ, Z_mir, circ_feats_t, mir_feats_t,
                    mask_rate=args.rfm_node_mask_rate,
                )

                # ---- 总损失 ----
                total_loss = (
                    sup_loss
                    + args.lambda_contrast * contrast_loss
                    + args.lambda_edge * edge_pred_loss
                    + args.lambda_node * node_mask_loss
                )

                optimizer.zero_grad()
                total_loss.backward()
                optimizer.step()

                # ---- 验证 ----
                if epoch % args.rfm_val_freq == 0 or epoch == args.rfm_epochs:
                    model.eval()
                    with torch.no_grad():
                        Z_circ_v, Z_mir_v, _, _, _ = model.encode(
                            circ_feats_t, mir_feats_t
                        )
                        # 验证对打分
                        val_pairs_t = torch.from_numpy(val_pairs).long().to(device)
                        val_scores = model.decode(
                            Z_circ_v, Z_mir_v, val_pairs_t[:, 1], val_pairs_t[:, 0]
                        ).cpu().numpy()
                        val_labels = label[tuple(val_pairs.T)]

                    metric_tmp = self.get_metrics(val_labels, val_scores)

                    if metric_tmp[0] > best_auc:
                        best_auc = metric_tmp[0]
                        best_aupr = metric_tmp[1]
                        best_result = metric_tmp
                        # 保存最佳检查点对应的标签与预测概率（sigmoid 归一化到 (0,1)）
                        best_val_labels = val_labels.astype(int).copy()
                        best_val_probs = torch.sigmoid(
                            torch.from_numpy(val_scores)
                        ).numpy()

            # ---- 记录本折结果 ----
            metric += np.asarray(best_result)
            per_fold_metrics.append(np.asarray(best_result, dtype=float))

            result = {
                'AUC': best_result[0], 'AUPR': best_result[1],
                'F1_Score': best_result[2], 'ACC': best_result[3],
                'Precision': best_result[4], 'Recall': best_result[5],
                'Specificity': best_result[6], 'MCC': best_result[7],
            }
            evaluation_results['Fold {}'.format(fold + 1)] = result

            # 收集本折最佳检查点结果，供 5 折 ROC/PR 绘图
            fold_plot_results.append({
                "y_true": best_val_labels,
                "y_scores": best_val_probs,
                "auc": best_result[0],
                "aupr": best_result[1],
                "fold": fold + 1,
            })

            print('fold {}: AUC:{:.4f} AUPR:{:.4f} F1:{:.4f} ACC:{:.4f} '
                  'Precision:{:.4f} Recall:{:.4f} Specificity:{:.4f} MCC:{:.4f}'.format(
                      fold + 1, *[best_result[i] for i in range(8)]))

        # ---- 汇总 ----
        final_result = (metric / args.k_fold)[0]
        final_std = np.std(np.asarray(per_fold_metrics), axis=0)
        metric_names = ['AUC', 'AUPR', 'F1_Score', 'ACC',
                        'Precision', 'Recall', 'Specificity', 'MCC']
        final_results = {
            name: float(final_result[i]) for i, name in enumerate(metric_names)
        }
        final_results['STD'] = {
            name: float(final_std[i]) for i, name in enumerate(metric_names)
        }

        print("Average:")
        for i, name in enumerate(metric_names):
            print("  {:<12} {:.4f}  ±  {:.4f}".format(
                name, final_result[i], final_std[i]))

        # ---- 绘制 5 折 ROC/PR 曲线 ----
        save_dir = getattr(args, 'savepath', './result/')
        plotter = ROCPRPlotter(save_dir=os.path.join(save_dir, 'figures'))
        plotter.plot_5fold_curves(
            fold_plot_results,
            model_name="RHGAT",
            show_mean=True,
        )

        return evaluation_results, final_results

    # ------------------------------------------------------------------
    # 辅助：打分、负采样、节点掩码
    # ------------------------------------------------------------------
    def _score_edges(self, model, Z_circ, Z_mir, edges):
        """edges : (E, 2) numpy (mir, circ)，返回 (E,) 分数。"""
        if len(edges) == 0:
            return torch.zeros(0)
        edges_t = torch.from_numpy(edges).long().to(Z_circ.device)
        return model.decode(Z_circ, Z_mir, edges_t[:, 1], edges_t[:, 0]).detach()

    def _sample_negatives(self, neg_pool, neg_scores, epoch, n_neg, hard_miner, rng):
        """困难负样本课程采样：从候选池 neg_pool 中按分数选困难负例。"""
        if len(neg_pool) <= n_neg:
            return neg_pool
        sel = hard_miner.sample_hard_negatives(
            neg_pool, neg_scores, epoch, n_neg, rng
        )
        return neg_pool[sel]

    def _masked_node_loss(self, model, Z_circ, Z_mir, circ_feats_t, mir_feats_t, mask_rate=0.15):
        """节点特征重建：用统一表示重建中心化后的 RNA-FM sequence embedding。

        这是去噪自编码式的自监督信号——模型需要从融合/图传播后的表示
        恢复出原始序列语义，迫使编码器保留信息，防止过度坍缩。
        """
        n_circ = Z_circ.shape[0]
        n_mir = Z_mir.shape[0]

        # circ 侧重建
        n_mask_c = max(1, int(n_circ * mask_rate))
        mask_c = torch.randperm(n_circ, device=Z_circ.device)[:n_mask_c]
        seq_target_c = circ_feats_t[0]                  # (N_c, 640) 已中心化
        recon_c = model.recon_proj_circ(Z_circ)
        loss_c = F.mse_loss(recon_c[mask_c], seq_target_c[mask_c])

        # mir 侧重建
        n_mask_m = max(1, int(n_mir * mask_rate))
        mask_m = torch.randperm(n_mir, device=Z_mir.device)[:n_mask_m]
        seq_target_m = mir_feats_t[0]
        recon_m = model.recon_proj_mir(Z_mir)
        loss_m = F.mse_loss(recon_m[mask_m], seq_target_m[mask_m])

        return loss_c + loss_m
