"""
离线提取 RNA-FM 序列 embedding 并缓存为 npy。

用法：
    python extract_rna_embeddings.py

产物（默认写到 ../pretrained/emb_cache/）：
    circ_emb.npy   (2346, 640)
    mir_emb.npy    (962, 640)
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from rna_fm import RNAFoundationModel, load_sequences

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, "Data")
MODEL_DIR = os.path.join(ROOT, "pretrained", "rnafm")

MIR_NUM = 962
CIRC_NUM = 2346


def main():
    model = RNAFoundationModel(model_dir=MODEL_DIR)

    print("[1/2] 提取 circRNA embedding ...")
    circ_ids, circ_seqs = load_sequences(
        os.path.join(DATA, "circRNA.csv"), n=CIRC_NUM
    )
    print("  circRNA 序列数:", len(circ_seqs))
    circ_emb = model.encode_cached("circ_emb", circ_seqs, max_len=1024)
    print("  circ_emb:", circ_emb.shape)

    print("[2/2] 提取 miRNA embedding ...")
    mir_ids, mir_seqs = load_sequences(
        os.path.join(DATA, "miRNA.csv"), n=MIR_NUM
    )
    print("  miRNA 序列数:", len(mir_seqs))
    mir_emb = model.encode_cached("mir_emb", mir_seqs, max_len=1024)
    print("  mir_emb:", mir_emb.shape)

    print("DONE")
    print("  circ_emb ->", os.path.join(model.cache_dir, "circ_emb.npy"))
    print("  mir_emb  ->", os.path.join(model.cache_dir, "mir_emb.npy"))


if __name__ == "__main__":
    main()
