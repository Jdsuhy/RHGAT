# -*- Coding: utf-8 -*-
import csv

import torch
import torch as t
import numpy as np

EOS = 1e-10


_DATAPRO_SINGLETON = None


def _get_datapro():
    """返回模块级 datapro 单例，避免高频调用处反复 new 实例。"""
    global _DATAPRO_SINGLETON
    if _DATAPRO_SINGLETON is None:
        _DATAPRO_SINGLETON = datapro()
    return _DATAPRO_SINGLETON


class datapro:
    def __init__(self):
        super(datapro, self).__init__()

    def read_csv(self, filename):
        with open(filename, 'r', newline='') as csv_file:
            reader = csv.reader(csv_file)
            md_data = []
            md_data += [[float(i) for i in row] for row in reader]
            return t.Tensor(md_data)

    def datasplit(self, args, m_d_matrix):
        """
        沿用现有 1:1 负采样与 k 折划分：
        正样本全部保留，负样本随机采样与正样本等量，随后打乱并切 k 折。
        """
        # positive samples
        pos_index = np.array(
            np.where(m_d_matrix == 1)
        ).T

        # negative samples
        neg_index = np.array(
            np.where(m_d_matrix == 0)
        ).T

        # shuffle
        np.random.shuffle(neg_index)

        # negative sampling ratio（1:1，稀疏正标签下提升 AUPR）
        neg_num = min(
            len(neg_index),
            len(pos_index)
        )

        neg_index = neg_index[:neg_num]

        # combine
        index = np.vstack(
            (
                pos_index,
                neg_index
            )
        )

        # shuffle all samples
        np.random.shuffle(index)

        # k-fold
        folds = []

        fold_size = len(index) // args.k_fold

        for i in range(args.k_fold):
            if i == args.k_fold - 1:
                fold = index[i * fold_size:]
            else:
                fold = index[i * fold_size:(i + 1) * fold_size]

            # ensure shape (N,2)
            fold = np.asarray(fold)
            folds.append(fold)

        return folds
