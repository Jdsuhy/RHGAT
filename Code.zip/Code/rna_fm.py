"""
RNA Foundation Model 封装（RNA-FM / multimolecule）。

职责：用本地预训练的 RNA-FM（multimolecule/rnafm，约 100M 参数）对
circRNA 与 miRNA 的序列提取深层语义表示，输出统一的序列级 embedding。

设计要点
--------
1. 懒加载 + 结果缓存：embedding 首次提取后落盘为 npy，之后直接复用，
   避免每次训练都跑一遍大模型前向。
2. 长序列截断：RNA-FM 的 max_position_embeddings=1026（有效 1024 token），
   circRNA 序列常长达数千 nt。默认对超长序列做「首部 + 尾部」拼接截断，
   保留 5' 与 3' 端信息；miRNA 短序列直接右填充。
3. 序列级表示：取 <cls>（BOS，id=1）位置 0 的 hidden state 作为整条序列
   的表征（与 RNA-FM 原始预训练的分类头语义一致）。
4. T->U：tokenizer 已配置 replace_T_with_U，DNA 的 T 会被自动视作 U。

用法
----
    from rna_fm import RNAFoundationModel
    fm = RNAFoundationModel(model_dir=..., cache_dir=...)
    circ_emb = fm.encode(circ_sequences, max_len=1024)   # (N_circ, 640)
    mir_emb  = fm.encode(mir_sequences,  max_len=1024)   # (N_mir, 640)
"""

import os
import numpy as np
import torch

_MODEL_TYPE = "rnafm"
_EMB_DIM = 640


class RNAFoundationModel:
    def __init__(self, model_dir, cache_dir=None, device=None):
        """
        model_dir : 预训练权重目录（含 config.json / model.safetensors）
        cache_dir : embedding 缓存目录（npy），None 则取 model_dir/../emb_cache
        device    : 'cuda' / 'cpu'，None 时自动选择
        """
        self.model_dir = model_dir
        self.cache_dir = cache_dir or os.path.join(
            os.path.dirname(model_dir.rstrip("/\\")), "emb_cache"
        )
        os.makedirs(self.cache_dir, exist_ok=True)

        self.device = device or (
            "cuda" if torch.cuda.is_available() else "cpu"
        )
        self._model = None
        self._tokenizer = None

    # ------------------------------------------------------------------
    # 懒加载
    # ------------------------------------------------------------------
    def _load(self):
        if self._model is not None:
            return
        from multimolecule import RnaFmModel, RnaTokenizer

        self._tokenizer = RnaTokenizer.from_pretrained(self.model_dir)

        # 权重键名兼容：multimolecule/rnafm 的 safetensors 里权重带
        # "model." 前缀（如 model.encoder.layer.0...），而 RnaFmModel
        # 期望无前缀。这里手动加载并剥离前缀，避免 from_pretrained
        # 因键名不匹配而全部回退到随机初始化。
        self._model = RnaFmModel.from_pretrained(
            self.model_dir, ignore_mismatched_sizes=True
        )

        # 尝试用带前缀剥离的方式正确加载权重
        state = self._load_state_dict_stripped()
        if state is not None:
            missing, unexpected = self._model.load_state_dict(
                state, strict=False
            )
            if len(unexpected) == 0:
                # 成功覆盖：说明前缀剥离正确
                pass

        self._model.to(self.device)
        self._model.eval()

    def _load_state_dict_stripped(self):
        """从 safetensors 加载权重并剥离 'model.' 前缀。"""
        import os
        from safetensors.torch import load_file as load_safetensors

        for fname in ("model.safetensors", "pytorch_model.bin"):
            path = os.path.join(self.model_dir, fname)
            if not os.path.exists(path):
                continue
            try:
                if fname.endswith(".safetensors"):
                    raw = load_safetensors(path)
                else:
                    raw = torch.load(path, map_location="cpu")
            except Exception:
                continue

            state = {}
            for k, v in raw.items():
                kk = k
                if kk.startswith("model."):
                    kk = kk[len("model."):]
                state[kk] = v
            # 只保留模型主体权重（丢弃 lm_head / ss_head 等预训练任务头）
            return {k: v for k, v in state.items() if not k.startswith(("lm_head", "ss_head"))}

        return None

    # ------------------------------------------------------------------
    # 截断：首尾拼接（保留 5' + 3' 端）
    # ------------------------------------------------------------------
    @staticmethod
    def _truncate(seq, max_len):
        if len(seq) <= max_len:
            return seq
        head = max_len - max_len // 4      # 3/4 给头部
        tail = max_len // 4                # 1/4 给尾部
        return seq[:head] + seq[-tail:]

    # ------------------------------------------------------------------
    # 编码一批序列
    # ------------------------------------------------------------------
    def encode(self, sequences, max_len=1024, batch_size=8):
        """sequences : list[str]，返回 (N, 640) float32 embedding。"""
        self._load()

        seqs = [self._truncate(s.upper().replace("T", "U"), max_len)
                for s in sequences]

        embs = []
        with torch.no_grad():
            for i in range(0, len(seqs), batch_size):
                batch = seqs[i:i + batch_size]
                enc = self._tokenizer(
                    batch,
                    padding=True,
                    truncation=True,
                    max_length=max_len,
                    return_tensors="pt",
                )
                enc = {k: v.to(self.device) for k, v in enc.items()}
                out = self._model(**enc)
                # 取 hidden states 的 <cls> 位置（index 0）
                hidden = out.last_hidden_state
                if isinstance(hidden, tuple):
                    hidden = hidden[0]
                cls = hidden[:, 0, :]                       # (B, 640)
                embs.append(cls.cpu().numpy())

        emb = np.concatenate(embs, axis=0).astype(np.float32)
        assert emb.shape[1] == _EMB_DIM, emb.shape
        return emb

    # ------------------------------------------------------------------
    # 带缓存的实体编码
    # ------------------------------------------------------------------
    def encode_cached(self, name, sequences, max_len=1024):
        """按 name 缓存：已存在则读缓存，否则编码并落盘。"""
        cache_path = os.path.join(self.cache_dir, f"{name}.npy")
        if os.path.exists(cache_path):
            return np.load(cache_path)

        emb = self.encode(sequences, max_len=max_len)
        np.save(cache_path, emb)
        return emb


def load_sequences(csv_path, n=None):
    """读取 circRNA/miRNA 序列文件（第 0 列 id，第 1 列序列）。"""
    import csv
    ids, seqs = [], []
    with open(csv_path, "r", newline="") as f:
        reader = csv.reader(f)
        for row in reader:
            if len(row) < 2:
                continue
            ids.append(row[0])
            seqs.append(row[1])
    if n is not None:
        ids, seqs = ids[:n], seqs[:n]
    return ids, seqs
