"""
RHGAT: A Hybrid Dual-graph Transformer with Hypergraph Contrastive Learning
for circRNA-miRNA Interaction Prediction.

circRNA-miRNA 关联预测：RNA 基础模型增强 + 双图结构学习 + 双流图 Transformer。

完整流程：
1. RNA Foundation Model（RNA-FM）提取序列深层语义表示
2. Reliability-aware Gated Fusion 融合 sequence/structure/expression/similarity
3. Adaptive Bipartite Graph + Adaptive Hypergraph 双图结构学习
4. 双流 Graph Transformer（局部二部图流 + 全局超图流）+ 双向 Cross-Attention
5. 三种自监督任务（节点掩码重建 / 图-超图对比 / 边恢复预测）
6. 困难负样本课程学习（Curriculum Hard Negative Mining）
7. 关系解码器（Relation Decoder）预测关联概率

本文件只放「结构编码 + 融合」相关的可复用模块，训练流程放在
experiment_rnafm.py。

【防过平滑重构要点】
- 融合层：去掉 tanh 饱和激活，改用拼接 + 残差投影，保留节点区分度；
- 二部图：可学习投影后直接内积（不再 normalize 成余弦），让 logits 具备动态范围；
- 超图：softmax 加温度 + top-k 稀疏化，避免节点被均匀摊到所有超边；
- 图 Transformer：Identity 初始化的残差 + Post-LN，从恒等映射出发稳定传播。
"""

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


# ======================================================================
# 1. Reliability-aware Gated Fusion（多模态门控融合）
# ======================================================================
class ReliabilityAwareFusion(nn.Module):
    """
    把 sequence / structure / expression / similarity 多路信息融合成统一节点表示。

    核心思想：不同模态对每个节点的「可靠程度」不同，用门控机制动态估计
    每路模态的可靠性权重，再按权重聚合。

    【防坍缩改进】：
    - 各视图投影后不再经过 tanh（tanh 会饱和、压缩区分度），改用 LayerNorm + GELU；
    - 融合采用「拼接 → 残差 MLP」而非纯 softmax 加权求和，保留每路信息；
    - 可靠性门控仍保留，但作为 softmax 加权，并在最终加残差连接原始拼接特征。
    """

    def __init__(self, view_dims, out_dim, hidden=128):
        super().__init__()
        self.num_views = len(view_dims)
        self.out_dim = out_dim

        # 各视图先投影到统一维度
        self.projections = nn.ModuleList([
            nn.Linear(int(d), out_dim) for d in view_dims
        ])
        self.view_norms = nn.ModuleList([
            nn.LayerNorm(out_dim) for _ in view_dims
        ])

        # 可靠性打分网络：输入投影后表示，输出标量可靠性分数
        self.reliability = nn.Sequential(
            nn.Linear(out_dim, hidden),
            nn.GELU(),
            nn.Linear(hidden, 1),
        )

        # 拼接所有视图后的最终投影（残差 MLP）
        concat_dim = out_dim * self.num_views
        self.output_proj = nn.Sequential(
            nn.Linear(concat_dim, out_dim),
            nn.LayerNorm(out_dim),
            nn.GELU(),
            nn.Linear(out_dim, out_dim),
        )
        self.output_norm = nn.LayerNorm(out_dim)

    def forward(self, views, reliability_signals=None):
        """
        views : list of (N, d_i)
        reliability_signals : 可选 list of (N, 1)，各视图可靠度先验。
        返回 fused (N, out_dim), gates (N, V)
        """
        projected = []
        rel_scores = []
        for i, v in enumerate(views):
            h = self.projections[i](v)
            h = self.view_norms[i](h)
            h = F.gelu(h)
            projected.append(h)

            if reliability_signals is not None:
                sig = reliability_signals[i]
            else:
                sig = h
            rel_scores.append(self.reliability(sig))   # (N, 1)

        rel = torch.cat(rel_scores, dim=1)             # (N, V)
        gates = torch.softmax(rel, dim=1)              # (N, V) 可靠性门控

        # 门控加权聚合
        gated = torch.zeros_like(projected[0])
        for i, h in enumerate(projected):
            gated = gated + gates[:, i:i + 1] * h

        # 拼接所有视图 + 残差 MLP（保留多路信息，避免坍缩）
        concat = torch.cat(projected, dim=1)           # (N, V*out_dim)
        fused = self.output_proj(concat)
        # 门控结果作为残差补充
        fused = self.output_norm(fused + gated)
        return fused, gates


# ======================================================================
# 2. 自适应二部图（Adaptive Bipartite Graph）
# ======================================================================
class AdaptiveBipartiteGraph(nn.Module):
    """
    学习 circRNA-miRNA 之间的局部关联二部图。

    【防坍缩改进】：
    - 打分改为「可学习投影 + 内积 + 温度」，不再 F.normalize 成余弦
      （normalize 会把所有 logits 挤到狭小范围，导致 sigmoid 输出 0.5 全等）；
    - 输出做行归一化的软边权，并支持 top-k 稀疏化。
    """

    def __init__(self, in_dim, hidden_dim, topk=None, temperature=1.0):
        super().__init__()
        self.topk = topk
        self.temperature = temperature

        self.circ_proj = nn.Linear(in_dim, hidden_dim)
        self.mir_proj = nn.Linear(in_dim, hidden_dim)
        self.layer_norm_c = nn.LayerNorm(hidden_dim)
        self.layer_norm_m = nn.LayerNorm(hidden_dim)

    def forward(self, circ_feat, mir_feat, hard_topk=False):
        """
        circ_feat : (N_circ, in_dim)
        mir_feat  : (N_mir,  in_dim)
        返回 B : (N_circ, N_mir) 二部关联矩阵（0~1，soft）
        """
        c = self.layer_norm_c(self.circ_proj(circ_feat))
        m = self.layer_norm_m(self.mir_proj(mir_feat))

        # 直接内积打分（保留幅度动态范围），除以温度
        logits = torch.matmul(c, m.t()) / self.temperature   # (N_c, N_m)
        B = torch.sigmoid(logits)

        # 可选稀疏化：仅保留每行 top-k 最强关联
        if self.topk is not None and hard_topk:
            k = min(self.topk, B.shape[1])
            top_vals, _ = torch.topk(B, k, dim=1)
            thresh = top_vals[:, -1].unsqueeze(1)
            B = B * (B >= thresh).float()

        return B


# ======================================================================
# 3. 自适应超图（Adaptive Hypergraph）
# ======================================================================
class AdaptiveHypergraph(nn.Module):
    """
    用 K 个可学习的「超边原型」把节点软分配到超边，刻画 RNA 功能模块。

    【防坍缩改进】：
    - softmax 加温度，并在前向支持 top-k 稀疏化（每个节点只归属少数超边），
      避免节点被均匀摊到所有超边导致熵≈1 的退化解。
    """

    def __init__(self, in_dim, num_hyperedges, hidden_dim=128,
                 temperature=1.0, topk=None):
        super().__init__()
        self.num_hyperedges = num_hyperedges
        self.temperature = temperature
        self.topk = topk
        self.node_proj = nn.Linear(in_dim, hidden_dim)
        self.edge_proj = nn.Linear(in_dim, hidden_dim)
        self.prototype = nn.Parameter(
            torch.empty(num_hyperedges, hidden_dim)
        )
        nn.init.xavier_uniform_(self.prototype)

    def forward(self, node_feat, sparse=False):
        """
        node_feat : (N, in_dim)
        返回 H : (N, K) 软关联矩阵（行和为 1）
        """
        n = F.normalize(self.node_proj(node_feat), dim=1)     # (N, h)
        p = F.normalize(self.prototype, dim=1)               # (K, h)
        sim = torch.matmul(n, p.t()) / self.temperature      # (N, K)
        H = torch.softmax(sim, dim=1)                        # 行归一化软分配

        # 可选 top-k 稀疏化
        if self.topk is not None and sparse:
            k = min(self.topk, H.shape[1])
            top_vals, _ = torch.topk(H, k, dim=1)
            thresh = top_vals[:, -1].unsqueeze(1)
            H = H * (H >= thresh).float()
            H = H / (H.sum(dim=1, keepdim=True) + 1e-8)

        return H


# ======================================================================
# 4. 双流 Graph Transformer
# ======================================================================
class GraphTransformerLayer(nn.Module):
    """单层图 Transformer：多头自注意力 + 前馈，Post-LN 残差，可 Identity 初始化。"""

    def __init__(self, dim, num_heads=4, dropout=0.1, ff_mult=4):
        super().__init__()
        self.attn = nn.MultiheadAttention(dim, num_heads,
                                          dropout=dropout, batch_first=True)
        self.ff = nn.Sequential(
            nn.Linear(dim, dim * ff_mult),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dim * ff_mult, dim),
        )
        self.norm1 = nn.LayerNorm(dim)
        self.norm2 = nn.LayerNorm(dim)
        self.dropout = nn.Dropout(dropout)
        self._reset_parameters()

    def _reset_parameters(self):
        # 残差分支近似恒等初始化，让网络从「接近恒等映射」出发，
        # 避免首轮就把节点表示抹平。
        for m in self.ff:
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight, gain=0.5)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
        # 输出投影层偏小，减弱 FF 对表示的扰动
        if hasattr(self.ff[-1], 'weight'):
            nn.init.xavier_uniform_(self.ff[-1].weight, gain=0.2)
            nn.init.zeros_(self.ff[-1].bias)

    def forward(self, x):
        # x : (N, dim)
        x_in = x.unsqueeze(0)                           # (1, N, dim)
        attn_out, _ = self.attn(x_in, x_in, x_in)
        x = self.norm1(x + self.dropout(attn_out.squeeze(0)))
        ff_out = self.ff(x)
        x = self.norm2(x + self.dropout(ff_out))
        return x


class BipartiteGraphTransformer(nn.Module):
    """
    局部图流：在二部关联图 B 上对 circRNA 与 miRNA 节点做消息传递，
    再各自过 Transformer 编码局部结构。

    防过平滑关键：
    1. 二部图稀疏化（每行只保留 top-k 最强关联）；
    2. 消息聚合用可学习残差系数缩放，弱化聚合对原始表示的覆盖；
    3. 聚合后的表示经过 Transformer（近恒等初始化）稳定传播。
    """

    def __init__(self, dim, num_layers=1, num_heads=4, dropout=0.1,
                 topk=16, agg_weight=0.1):
        super().__init__()
        self.dim = dim
        self.topk = topk
        self.agg_weight = agg_weight
        self.circ_layers = nn.ModuleList([
            GraphTransformerLayer(dim, num_heads, dropout)
            for _ in range(num_layers)
        ])
        self.mir_layers = nn.ModuleList([
            GraphTransformerLayer(dim, num_heads, dropout)
            for _ in range(num_layers)
        ])

    def forward(self, circ_feat, mir_feat, B):
        """
        circ_feat : (N_c, dim)
        mir_feat  : (N_m, dim)
        B         : (N_c, N_m) 二部关联（soft，0~1）
        返回 Z_local_circ, Z_local_mir
        """
        # 稀疏化：每行只保留 top-k 最强关联
        if self.topk is not None and self.topk < B.shape[1]:
            k = self.topk
            top_vals, _ = torch.topk(B, k, dim=1)
            thresh = top_vals[:, -1].unsqueeze(1)
            B_sp = B * (B >= thresh).float()
        else:
            B_sp = B

        # 行/列归一化
        B_c2m = F.normalize(B_sp + 1e-8, p=1, dim=1)   # circ 聚合 mir
        B_m2c = F.normalize(B_sp + 1e-8, p=1, dim=0)   # mir 聚合 circ

        c_agg = torch.matmul(B_c2m, mir_feat)          # (N_c, dim)
        m_agg = torch.matmul(B_m2c.t(), circ_feat)     # (N_m, dim)

        # 弱化聚合 + 强残差，保留节点自身区分度
        c = circ_feat + self.agg_weight * c_agg
        m = mir_feat + self.agg_weight * m_agg

        for layer in self.circ_layers:
            c = layer(c)
        for layer in self.mir_layers:
            m = layer(m)

        return c, m


class HypergraphTransformer(nn.Module):
    """
    全局图流：在超图 H 上做「节点->超边->节点」两阶段聚合，捕捉高阶功能模块，
    再经过 Transformer 编码。
    """

    def __init__(self, dim, num_layers=1, num_heads=4, dropout=0.1,
                 agg_weight=0.1):
        super().__init__()
        self.agg_weight = agg_weight
        self.layers = nn.ModuleList([
            GraphTransformerLayer(dim, num_heads, dropout)
            for _ in range(num_layers)
        ])

    def hypergraph_conv(self, node_feat, H):
        """
        node_feat : (N, dim)
        H         : (N, K) 软关联
        返回高阶聚合后的节点表示 (N, dim)
        """
        # 节点 -> 超边
        edge_feat = torch.matmul(H.t(), node_feat)          # (K, dim)
        # 超边 -> 节点
        node_out = torch.matmul(H, edge_feat)               # (N, dim)
        # 归一化：按节点参与的超边强度
        deg = torch.matmul(H, H.sum(dim=0, keepdim=True).t()) + 1e-8  # (N,1)
        node_out = node_out / deg
        return node_out

    def forward(self, node_feat, H):
        agg = self.hypergraph_conv(node_feat, H)
        x = node_feat + self.agg_weight * agg
        for layer in self.layers:
            x = layer(x)
        return x


class CrossAttentionFusion(nn.Module):
    """双向 Cross-Attention：局部与全局表示相互对齐融合为统一表示 Z。"""

    def __init__(self, dim, num_heads=4, dropout=0.1):
        super().__init__()
        self.cross_attn = nn.MultiheadAttention(dim, num_heads,
                                                dropout=dropout, batch_first=True)
        self.norm = nn.LayerNorm(dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, z_local, z_global):
        """
        z_local  : (N, dim)
        z_global : (N, dim)
        返回 unified (N, dim)
        """
        q = z_local.unsqueeze(0)
        k = v = z_global.unsqueeze(0)
        out, _ = self.cross_attn(q, k, v)               # 局部 query 全局
        out = out.squeeze(0)
        z = self.norm(z_local + self.dropout(out))
        return z
