"""
自监督任务 + 困难负样本课程学习 + 关系解码器。

三种自监督任务（增强有限标注下的鲁棒性与泛化）：
1. 节点掩码重建（Masked Node Modeling）
2. 图—超图跨视图对比学习（Graph–Hypergraph Contrastive Learning）
3. 边恢复预测（Masked Edge Prediction）

困难负样本课程学习（Curriculum Hard Negative Mining）：
针对「未知关联 != 真实负关联」的特点，动态从负样本池中挑选
当前模型最易混淆（预测分数最高）的困难负例，随训练轮次逐步加大
困难度（课程），避免初期被噪声负例干扰。
"""

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


# ======================================================================
# 节点掩码重建（Masked Node Modeling）
# ======================================================================
class MaskedNodeModeling(nn.Module):
    """随机掩码部分节点的特征，用解码器重建原始特征。"""

    def __init__(self, dim, feature_dim):
        super().__init__()
        self.decoder = nn.Sequential(
            nn.Linear(dim, dim),
            nn.GELU(),
            nn.Linear(dim, feature_dim),
        )

    def forward(self, z, mask):
        """
        z    : (N, dim) 节点表示
        mask : (N,) bool，True 表示被掩码
        返回重建 logits (N, feature_dim) 与掩码索引
        """
        recon = self.decoder(z)
        return recon


def masked_node_loss(z, original_feat, feature_dim, mask_rate=0.15):
    """
    z             : (N, dim) 编码后的节点表示
    original_feat : (N, F) 原始节点特征（重建目标）
    返回重建 MSE 损失
    """
    N = z.shape[0]
    n_mask = max(1, int(N * mask_rate))
    mask_idx = torch.randperm(N, device=z.device)[:n_mask]

    decoder = MaskedNodeModeling(z.shape[1], original_feat.shape[1]).to(z.device)
    recon = decoder(z, mask_idx)                       # (N, F)

    loss = F.mse_loss(recon[mask_idx], original_feat[mask_idx])
    return loss


# ======================================================================
# 图—超图跨视图对比学习（Graph–Hypergraph Contrastive Learning）
# ======================================================================
def cross_view_contrastive_loss(z_local, z_global, temperature=0.5,
                                projection_dim=None):
    """
    z_local  : (N, dim) 局部二部图流表示
    z_global : (N, dim) 全局超图流表示
    同一节点的两个视图为正对，跨视图拉近；不同节点互斥（InfoNCE）。

    【防坍缩改进】：
    - 引入可学习的投影头（projection head）把两视图映射到对比空间，
      再 normalize + 温度缩放。这是 SimCLR 的关键：直接在编码空间做对比
      会让表征为满足对比目标而丢弃信息；投影头解耦了对比任务与下游任务。
    - 投影头由调用方（experiment_rnafm.py）传入，避免在无梯度模块里新建参数。
    """
    z1 = F.normalize(z_local, dim=1)
    z2 = F.normalize(z_global, dim=1)

    N = z1.shape[0]
    logits = torch.matmul(z1, z2.t()) / temperature      # (N, N)

    labels = torch.arange(N, device=z1.device)
    loss = F.cross_entropy(logits, labels)               # 对角线为正对

    return loss


# ======================================================================
# 对比投影头（Projection Head，SimCLR 风格）
# ======================================================================
class ContrastProjectionHead(nn.Module):
    """把节点表示投影到对比空间，解耦对比任务与下游任务。"""

    def __init__(self, in_dim, proj_dim=128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, in_dim),
            nn.BatchNorm1d(in_dim),
            nn.ReLU(),
            nn.Linear(in_dim, proj_dim),
        )

    def forward(self, x):
        return self.net(x)


# ======================================================================
# 边恢复预测（Masked Edge Prediction）
# ======================================================================
class EdgePredictionHead(nn.Module):
    """独立的边打分头（与关系解码器解耦），用于自监督边恢复任务。"""

    def __init__(self, dim, hidden=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim * 4, hidden),
            nn.ReLU(),
            nn.Linear(hidden, 1),
        )

    def forward(self, z_circ, z_mir, edges):
        """
        edges : (E, 2) 格式 (mir_idx, circ_idx)
        返回 (E,) logits
        """
        c = z_circ[edges[:, 1]]                          # (E, dim)
        m = z_mir[edges[:, 0]]                           # (E, dim)
        feat = torch.cat([c, m, (c - m).abs(), c * m], dim=1)
        return self.net(feat).squeeze(-1)


def masked_edge_prediction_loss(edge_head, z_circ, z_mir, edge_index, neg_pool,
                                mask_rate=0.15):
    """
    随机掩码部分已知关联边，训练模型判断「边是否存在」。

    edge_head  : EdgePredictionHead（可学习，与关系解码器解耦）
    z_circ     : (N_c, dim)
    z_mir      : (N_m, dim)
    edge_index : (E, 2) 已知正边，格式 (mir_idx, circ_idx)
    neg_pool   : (K, 2) 负边候选池，格式 (mir_idx, circ_idx)
    """
    E = edge_index.shape[0]
    n_mask = max(1, int(E * mask_rate))
    perm = torch.randperm(E, device=edge_index.device)[:n_mask]
    pos_edges = edge_index[perm]                         # (n_mask, 2)

    # 采样等量负边
    if neg_pool.shape[0] == 0:
        return torch.tensor(0.0, device=z_circ.device)
    n_neg = min(n_mask, neg_pool.shape[0])
    neg_perm = torch.randperm(neg_pool.shape[0], device=neg_pool.device)[:n_neg]
    neg_edges = neg_pool[neg_perm]

    pos_score = edge_head(z_circ, z_mir, pos_edges)
    neg_score = edge_head(z_circ, z_mir, neg_edges)

    pos_loss = F.binary_cross_entropy_with_logits(
        pos_score, torch.ones_like(pos_score)
    )
    neg_loss = F.binary_cross_entropy_with_logits(
        neg_score, torch.zeros_like(neg_score)
    )
    return pos_loss + neg_loss


# ======================================================================
# 困难负样本课程学习（Curriculum Hard Negative Mining）
# ======================================================================
class HardNegativeMining:
    """
    课程式困难负样本挖掘。

    随着训练推进，逐步提高「困难度阈值」：前期用易区分的负例，
    后期聚焦模型最易混淆的困难负例，模拟课程学习由易到难。

    困难度用当前模型的预测分数衡量：分数越高的负例越「困难」。
    """

    def __init__(self, start_epoch=5, curriculum_step=5,
                 hard_ratio_start=0.1, hard_ratio_end=0.5):
        self.start_epoch = start_epoch
        self.curriculum_step = curriculum_step
        self.hard_ratio_start = hard_ratio_start
        self.hard_ratio_end = hard_ratio_end

    def hard_ratio(self, epoch):
        """当前轮次应采样的困难负例比例（课程由易到难）。"""
        if epoch < self.start_epoch:
            return self.hard_ratio_start
        stage = (epoch - self.start_epoch) // self.curriculum_step
        # 每过 curriculum_step 轮，困难比例线性上升，直到上限
        ratio = self.hard_ratio_start + stage * 0.1
        return min(ratio, self.hard_ratio_end)

    def sample_hard_negatives(self, neg_pool, neg_scores, epoch, n_neg,
                              rng=None):
        """
        neg_pool    : (K, 2) 负边候选池
        neg_scores  : (K,) 当前模型对负边的预测分数（越高越困难）
        epoch       : 当前轮次
        n_neg       : 需要的负样本数
        rng         : numpy RandomState（可选，保证可复现）
        返回采样的负边索引（在 neg_pool 中的下标）
        """
        K = neg_pool.shape[0]
        ratio = self.hard_ratio(epoch)
        n_hard = min(int(n_neg * ratio), K)
        n_easy = n_neg - n_hard

        if rng is None:
            rng = np.random

        # 困难负例：取分数最高的 top-n_hard
        hard_order = np.argsort(-neg_scores)             # 分数降序
        hard_idx = hard_order[:n_hard]

        # 简单负例：从其余随机采样
        easy_candidates = hard_order[n_hard:]
        if n_easy > 0 and len(easy_candidates) > 0:
            easy_idx = rng.choice(easy_candidates, size=n_easy, replace=False)
        else:
            easy_idx = np.array([], dtype=np.int64)

        selected = np.concatenate([hard_idx, easy_idx])
        rng.shuffle(selected)
        return selected


# ======================================================================
# 关系解码器（Relation Decoder）
# ======================================================================
class RelationDecoder(nn.Module):
    """
    双分支关系解码器：
    - 内积分支：circ 与 mir 表示的内积，捕捉线性关联；
    - MLP 分支：拼接 [circ; mir; |circ-mir|; circ*mir] 过 MLP，捕捉非线性交互。
    最终分数为两者加权（可学习门控）。
    """

    def __init__(self, dim, hidden=128):
        super().__init__()
        self.mlp = nn.Sequential(
            nn.Linear(dim * 4, hidden),
            nn.GELU(),
            nn.Dropout(0.1),
            nn.Linear(hidden, hidden // 2),
            nn.GELU(),
            nn.Linear(hidden // 2, 1),
        )
        self.gate = nn.Linear(dim * 2, 1)

    def forward(self, z_circ, z_mir, circ_idx, mir_idx):
        """
        z_circ    : (N_c, dim)
        z_mir     : (N_m, dim)
        circ_idx  : (E,) 边对应的 circ 节点索引
        mir_idx   : (E,) 边对应的 mir 节点索引
        返回 (E,) 预测分数（logits）
        """
        c = z_circ[circ_idx]                             # (E, dim)
        m = z_mir[mir_idx]                               # (E, dim)

        # 内积分支
        dot = (c * m).sum(dim=1, keepdim=True)           # (E, 1)

        # MLP 分支
        feat = torch.cat([c, m, (c - m).abs(), c * m], dim=1)  # (E, 4dim)
        mlp_out = self.mlp(feat)                         # (E, 1)

        # 可学习门控融合两分支
        gate = torch.sigmoid(self.gate(torch.cat([c, m], dim=1)))
        score = gate * dot + (1 - gate) * mlp_out

        return score.squeeze(-1)                         # (E,)
