"""
RHGAT: A Hybrid Dual-graph Transformer with Hypergraph Contrastive Learning
for circRNA-miRNA Interaction Prediction.

入口：RNA 基础模型增强 + 双图结构学习 + 双流图 Transformer。

用法：
    python main_rnafm.py
"""

import warnings
from args import config
from experiment_rnafm import RNAFMExperiment

warnings.filterwarnings("ignore")


def main():
    args = config()
    experiment = RNAFMExperiment(args)
    results, final_results = experiment.train()

    # 打印最终结果
    print("\n===== Final Results =====")
    for k, v in final_results.items():
        if k != 'STD':
            print("  {}: {:.4f}".format(k, v))
    print("  STD:", {k: round(v, 4) for k, v in final_results['STD'].items()})


if __name__ == "__main__":
    main()
