import argparse


def config():
    parser = argparse.ArgumentParser()

    # ------------------------------------------------------------------
    # 数据集
    # ------------------------------------------------------------------
    parser.add_argument('-miRNA', type=str, default=['mi_str_similarity', 'mi_exp_similarity', 'mi_seq_similarity'])
    parser.add_argument('-circRNA', type=str, default=['circ_seq_similarity', 'circ_str_similarity', 'circ_exp_similarity'])
    parser.add_argument('-datapath', type=str, default='../Data/')
    parser.add_argument('-savepath', type=str, default='./result/')
    parser.add_argument('-m_num', type=int, default=962)
    parser.add_argument('-d_num', type=int, default=2346)

    # ------------------------------------------------------------------
    # 实验设置
    # ------------------------------------------------------------------
    parser.add_argument('-seed', type=int, default=42)
    parser.add_argument('-k_fold', type=int, default=5, choices=[5, 10])
    parser.add_argument('-gpu', type=int, default=0)

    # ------------------------------------------------------------------
    # RNA 基础模型增强 + 双图结构学习 + 双流图 Transformer（新方法）
    # ------------------------------------------------------------------
    parser.add_argument('-rfm_epochs', type=int, default=150,
                        help='new method training epochs')
    parser.add_argument('-rfm_lr', type=float, default=0.001)
    parser.add_argument('-rfm_wdecay', type=float, default=1e-4)
    parser.add_argument('-rfm_hidden', type=int, default=128,
                        help='hidden dim after gated fusion')
    parser.add_argument('-rfm_temperature', type=float, default=5.0,
                        help='temperature for bipartite scoring (higher=smoother)')
    parser.add_argument('-rfm_sim_dim', type=int, default=64,
                        help='SVD components kept from similarity matrices for node feats')
    parser.add_argument('-use_graph_stream', type=int, default=1, choices=[0, 1],
                        help='1: enable bipartite/hypergraph + transformer stream; '
                             '0: lightweight gated-fusion only (avoid over-smoothing)')
    parser.add_argument('-rfm_tf_layers', type=int, default=1)
    parser.add_argument('-rfm_heads', type=int, default=4)
    parser.add_argument('-rfm_dropout', type=float, default=0.1)
    parser.add_argument('-rfm_val_freq', type=int, default=5)
    parser.add_argument('-num_hyperedges', type=int, default=64,
                        help='number of hyperedge prototypes')
    parser.add_argument('-bip_topk', type=int, default=32,
                        help='top-k sparsification of bipartite graph per row')
    parser.add_argument('-hyper_topk', type=int, default=16,
                        help='top-k sparsification of hypergraph assignment')
    parser.add_argument('-hyper_temperature', type=float, default=0.5,
                        help='temperature for hypergraph softmax (lower=sparser)')
    parser.add_argument('-graph_agg_weight', type=float, default=0.2,
                        help='residual weight of graph message aggregation')

    # 三种自监督损失权重（投影头解耦对比、独立边头、去噪重建）
    parser.add_argument('-lambda_contrast', type=float, default=0.1,
                        help='weight of graph-hypergraph contrastive loss')
    parser.add_argument('-lambda_edge', type=float, default=0.05,
                        help='weight of masked edge prediction loss')
    parser.add_argument('-lambda_node', type=float, default=0.1,
                        help='weight of masked node modeling loss')
    parser.add_argument('-rfm_cl_temp', type=float, default=0.5,
                        help='temperature for cross-view contrastive loss')
    parser.add_argument('-rfm_edge_mask_rate', type=float, default=0.15)
    parser.add_argument('-rfm_node_mask_rate', type=float, default=0.15)

    # 困难负样本课程学习（200ep 下为正贡献：AUC 0.9572→0.9617）
    parser.add_argument('-hard_start_epoch', type=int, default=20)
    parser.add_argument('-hard_step', type=int, default=5)
    parser.add_argument('-hard_ratio_start', type=float, default=0.1)
    parser.add_argument('-hard_ratio_end', type=float, default=0.4)

    args = parser.parse_args()
    return args
