"""串行跑多个消融配置，避免 GPU 竞争。用环境变量 ABL_EXP 选择实验。"""
import os
import sys
import time

sys.path.insert(0, '.')
from args import config
from experiment_rnafm import RNAFMExperiment


def run(name, **overrides):
    args = config()
    for k, v in overrides.items():
        setattr(args, k, v)
    t0 = time.time()
    exp = RNAFMExperiment(args)
    results, final = exp.train()
    dt = time.time() - t0
    print("\n>>> {}: AUC={:.4f} AUPR={:.4f} ({:.0f}s)".format(
        name, final['AUC'], final['AUPR'], dt))
    return final


if __name__ == '__main__':
    opt = os.environ.get('ABL_EXP', 'all')

    if opt in ('all', 'a'):
        # 基线（已固化）：100 epoch
        run('BASELINE-100ep', rfm_epochs=100)

    if opt in ('all', 'b'):
        # 实验A：200 epoch
        run('A-200ep', rfm_epochs=200)

    if opt in ('all', 'c'):
        # 实验B：200 epoch + 困难负样本课程
        run('B-200ep-hardneg', rfm_epochs=200,
            hard_ratio_start=0.1, hard_ratio_end=0.4, hard_start_epoch=20)

    if opt in ('all', 'd'):
        # 实验C：调学习率
        run('C-lr0.002', rfm_epochs=150, rfm_lr=0.002, rfm_wdecay=1e-5)
